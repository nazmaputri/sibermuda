<?php $__env->startSection('content'); ?>
    <div class="container mx-auto">
        <div class="bg-white shadow-lg rounded-lg overflow-hidden p-6 border border-gray-200">
            <h1 class="text-xl font-semibold text-gray-700 border-b-2 mb-1 flex justify-between items-center">
                <span>Hasil Kuis : <?php echo e($quiz->title); ?></span>
                <div class="px-1 rounded-md">
                    <span class="text-3xl cursor-pointer text-red-500 hover:text-red-400" onclick="closeQuizResult()">×</span>
                </div>
            </h1>
            <script>
                function closeQuizResult() {
                    // Redirect ke route 'study-peserta' dengan ID course
                    window.location.href = "<?php echo e(route('study-peserta', ['id' => $course->id])); ?>";
                }
            </script>
            <div class="mt-6 flex flex-col lg:flex-row gap-8">
                <div class="lg:w-1/3 bg-white shadow-md rounded-lg p-6 sticky top-6 border">
                    <h2 class="text-lg font-semibold text-gray-700 border-b-2 pb-2">Skor Anda</h2>
                
                    <!-- Tanggal Ujian (Paling Atas) -->
                    <p class="text-sm text-gray-700 mt-2">
                        Tanggal Mengerjakan : <?php echo e(\Carbon\Carbon::parse($startTime)->format('d M Y')); ?>

                    </p>
                
                    <!-- Menggunakan Flexbox untuk mengatur Total Soal dan Skor agar bersebelahan -->
                    <div class="flex justify-between items-center mt-4 space-x-2 p-4">
                        <!-- Total Soal -->
                        <div class="flex flex-col items-center text-center">
                            <p class="text-lg text-gray-700">Total Soal :</p>
                            <p class="text-2xl font-semibold text-gray-700"><?php echo e(count($quiz->questions)); ?></p>
                        </div>         
                        
                        <!-- Skor -->
                        <div class="flex flex-col items-center text-center">
                            <p class="text-lg text-gray-700">Skor :</p>
                            <p class="text-2xl font-semibold text-blue-500"><?php echo e($score); ?></p>
                        </div>                        
                    </div>                    
                
                    <!-- Status Lulus atau Tidak -->
                    <?php if($score >= 70): ?>
                        <p class="text-green-500 text-center mt-4">Selamat, Anda lulus kuis ini!</p>
                    <?php else: ?>
                        <p class="text-red-500 text-center mt-4">Maaf, Anda belum lulus kuis ini.</p>
                    <?php endif; ?>
                </div>                             

                <!-- Detail Jawaban -->
                <div class="lg:w-2/3 bg-white shadow-md rounded-lg border p-6 overflow-y-auto max-h-[calc(100vh-200px)]">
                    <h2 class="text-lg font-semibold text-gray-700 mb-4 border-b-2 pb-2">Detail Jawaban</h2>
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border-b border-gray-200 py-4">
                            <p class="font-semibold text-gray-700"><?php echo e($result['question']); ?></p>
                            <p class="mt-1">
                                <span class="font-medium text-gray-600">Jawaban Anda :</span>
                                <span class="<?php echo e($result['is_correct'] ? 'text-green-500' : 'text-red-500'); ?>">
                                    <?php echo e($result['submitted_answer'] ?? 'Tidak dijawab'); ?>

                                </span>
                            </p>
                            <p class="mt-1">
                                <span class="font-medium text-gray-600">Jawaban Benar :</span>
                                <span class="text-green-500"><?php echo e($result['correct_answer']); ?></span>
                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-peserta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-peserta/quiz-result.blade.php ENDPATH**/ ?>