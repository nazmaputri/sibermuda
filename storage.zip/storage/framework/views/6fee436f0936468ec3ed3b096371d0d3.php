<?php $__env->startSection('title', 'Tambah Diskon'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mx-auto bg-white rounded-lg p-5 border border-gray-200">
    <!-- Wrapper div dengan background putih, padding, dan shadow -->
    <div class="">
        <h2 class="text-xl font-semibold text-gray-700 text-center w-full border-b-2 border-gray-300 pb-2">Tambah Diskon</h2>

        <!-- Formulir Diskon -->
        <form action="<?php echo e(route('discount.store')); ?>" method="POST" class="mt-4 grid grid-col-1 md:grid-cols-2 space-x-3">
            <?php echo csrf_field(); ?>

            <!-- Kode Kupon -->
            <div class="mb-4">
                <label class="block text-gray-700 pb-2 font-semibold">Kode Diskon</label>
                <input type="text" name="coupon_code" class="border px-4 py-2 w-full text-sm text-gray-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['coupon_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan kode kupon">
                <?php $__errorArgs = ['coupon_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1" id="coupon_code-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Persen Diskon -->
            <div class="mb-4">
                <label class="block text-gray-700 pb-2 font-semibold">Persen Diskon (%)</label>
                <input type="number" name="discount_percentage" min="1" max="100" class="border px-4 py-2 w-full text-sm text-gray-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['discount_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan persentase diskon">
                <?php $__errorArgs = ['discount_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1" id="discount_percentage-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tanggal Mulai -->
            <div class="mb-4">
                <label class="block text-gray-700 pb-2 font-semibold">Tanggal Mulai</label>
                <input type="date" name="start_date" class="border px-4 py-2 w-full text-sm text-gray-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1" id="start_date-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tanggal Berakhir -->
            <div class="mb-4">
                <label class="block text-gray-700 pb-2 font-semibold">Tanggal Berakhir</label>
                <input type="date" name="end_date" class="border px-4 py-2 w-full text-sm text-gray-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1" id="end_date-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Jam Mulai -->
            <div class="mb-4">
                <label class="block text-gray-700 pb-2 font-semibold">Jam Mulai</label>
                <input type="time" name="start_time" class="border px-4 py-2 w-full text-sm text-gray-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1" id="start_time-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Jam Berakhir -->
            <div class="mb-4">
                <label class="block text-gray-700 pb-2 font-semibold">Jam Berakhir</label>
                <input type="time" name="end_time" class="border px-4 py-2 w-full text-sm text-gray-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1" id="end_time-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Terapkan ke Semua Kursus -->
            <div class="mt-4">
                <input type="hidden" name="apply_to_all" value="0">
                <label class="flex items-center space-x-2">
                    <input type="checkbox" name="apply_to_all" id="applyToAll" value="1"
                        class="rounded border-gray-300 text-blue-600 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400">
                    <span class="text-gray-700">Terapkan ke semua kursus</span>
                </label>
            </div>

            <!-- Dropdown Pilih Kursus -->
            <div id="courseSelection" class="mt-4" x-data="{ open: false, selectedCourses: [], searchTerm: '' }" x-show="!applyToAll">
                <label class="block text-gray-700 pb-2 font-semibold">Pilih Kursus</label>

                <div class="relative">
                    <!-- Button untuk membuka dropdown -->
                    <button @click="open = !open" type="button"
                        class="border px-4 py-2 text-gray-700 w-full rounded-lg bg-white flex justify-between items-center focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400">
                        <span class="block overflow-x-auto whitespace-nowrap scrollbar-thin scrollbar-thumb-rounded scrollbar-thumb-gray-300">
                            <span x-text="selectedCourses.length > 0 ? selectedCourses.join(', ') : 'Pilih Kursus'"></span>
                        </span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                    </button>

                    <!-- Dropdown menu -->
                    <div x-show="open" @click.away="open = false" class="absolute z-10 mt-1 w-full bg-white border rounded-lg shadow-lg">
                        <div class="p-2">
                            <input type="text" placeholder="Cari kursus..." x-model="searchTerm"
                                class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400">
                        </div>
                        <ul class="max-h-40 overflow-y-auto">
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="px-4 py-2 hover:bg-blue-100 cursor-pointer text-gray-700 text-sm"
                                    @click="selectedCourses.includes('<?php echo e($course->title); ?>') 
                                        ? selectedCourses.splice(selectedCourses.indexOf('<?php echo e($course->title); ?>'), 1) 
                                        : selectedCourses.push('<?php echo e($course->title); ?>')">
                                    <input type="checkbox" name="courses[]" value="<?php echo e($course->id); ?>" class="mr-2 text-gray-700" x-bind:checked="selectedCourses.includes('<?php echo e($course->title); ?>')">
                                    <?php echo e($course->title); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <p class="text-sm text-gray-500 mt-1">* Klik untuk memilih, gunakan CTRL untuk multi-select.</p>
            </div>

            <!-- Tombol -->
            <div class="col-span-1 md:col-span-2 mt-6 flex justify-end space-x-2">
                <a href="<?php echo e(route('discount')); ?>" class="bg-red-400 hover:bg-red-300 text-white font-semibold py-2 px-4 rounded-md">
                    Batal
                </a>
                <button type="submit" class="bg-sky-400 hover:bg-sky-300 text-white font-semibold py-2 px-4 rounded-md">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('discountForm', () => ({
            applyToAll: false,
        }));
    });

    document.getElementById('applyToAll').addEventListener('change', function () {
        document.getElementById('courseSelection').style.display = this.checked ? 'none' : 'block';
    });

    // Fungsi untuk menghapus class error dan menyembunyikan pesan error validasi
    document.addEventListener('DOMContentLoaded', function () {
    const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('input', function () {
                removeErrorStyles(input.id);
            });
        });
    });

    function removeErrorStyles(inputId) {
        const input = document.getElementById(inputId);
        if (input) {
            input.classList.remove('border-red-500', 'focus:ring-red-500', 'text-red-500');
            const errorMessage = document.getElementById(inputId + '-error');
            if (errorMessage) {
                errorMessage.style.display = 'none';
            }
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-admin/discount-tambah.blade.php ENDPATH**/ ?>