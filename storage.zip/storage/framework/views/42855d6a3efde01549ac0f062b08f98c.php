<?php $__env->startSection('title', 'Keranjang Saya'); ?>
<?php $__env->startSection('content'); ?>
    <div class="bg-white border border-gray-200 p-8 rounded-lg shadow-md">
        <!-- <div id="flash-container"></div> -->

        <!-- Pemberitahuan Diskon (Tetap Ada di Atas Keranjang) -->
        <?php if($activeDiscount): ?>
        <div class="bg-yellow-100 text-yellow-700 p-4 mb-4 rounded-lg">
            <h3 class="font-bold text-lg">🎉 Kode kupon: <span class=""><?php echo e($activeDiscount->coupon_code); ?></span></h3>
            <p class="text-sm">Diskon sebesar <strong><?php echo e($activeDiscount->discount_percentage); ?>%</strong> berlaku hingga <span id="discount-end"><?php echo e(\Carbon\Carbon::parse($activeDiscount->end_date)->translatedFormat('d F Y')); ?> <?php echo e($activeDiscount->end_time); ?></span>.</p>
            <div class="text-red-600 font-semibold text-sm mt-2" id="countdown-timer"></div>
        </div>
        <?php endif; ?>
        <!-- Tambahkan Countdown Timer -->
        <script>
            function startCountdown(endDate) {
                let countDownDate = new Date(endDate).getTime();

                let x = setInterval(function() {
                    let now = new Date().getTime();
                    let distance = countDownDate - now;

                    if (distance < 0) {
                        clearInterval(x);
                        document.getElementById("countdown-timer").innerHTML = "⏳ Diskon telah berakhir.";
                        return;
                    }

                    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    let seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    document.getElementById("countdown-timer").innerHTML = ⏳ Berakhir dalam: ${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik;
                }, 1000);
            }

            let discountEnd = document.getElementById("discount-end")?.textContent;
            if (discountEnd) startCountdown(discountEnd);
        </script>
        <?php if($carts->isEmpty()): ?>
            <!-- Jika keranjang kosong -->
            <div class="text-center py-3">
                <p class="text-gray-500">Keranjang Kamu masih kosong. Yuk, pilih kursus favoritmu!</p>
                <a href="<?php echo e(route('kategori-peserta')); ?>"
                    class="mt-4 font-semibold inline-block bg-sky-400 text-white py-1.5 px-5 rounded-lg hover:bg-sky-300 transition shadow-lg">
                    Jelajahi Kursus
                </a>
            </div>
        <?php else: ?>
        <div class="flex flex-col lg:flex-row gap-6">
        <!-- kontainer untuk kursus yang ada di keranjang -->
        <div class="flex flex-col bg-white border border-gray-200 p-3 rounded-lg shadow lg:w-2/3 md:min-h-40">
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center space-x-4 mb-3 pb-2 <?php if(!$loop->last || $loop->first && !$loop->last): ?> border-b border-gray-200 <?php endif; ?>">
                    <img src="<?php echo e(asset('storage/' . $cart->course->image_path)); ?>" alt="Course Image" class="w-24 h-24 object-cover rounded-md"/>
        
                    <!-- Informasi Produk -->
                    <div class="flex-1 space-y-1">
                        <h2 class="text-md font-semibold text-gray-700 capitalize"><?php echo e($cart->course->title); ?></h2>
                        <p class="text-sm font-semibold text-red-400">Rp. <span class=""><?php echo e(number_format($cart->course->price, 0, ',', '.')); ?></span></p>
                        <form action="<?php echo e(route('cart.remove', $cart->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="flex text-center items-center justify-center rounded-md text-red text-xs" type="submit">
                                <span class="text-sm text-red-400">Hapus</span>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- kontainer untuk apply kupon, total harga dan beli -->
        <div class="bg-white border border-gray-200 p-3 rounded-lg shadow flex-1 max-h-40">
            <!-- Input Kupon -->
            <div class="flex space-x-2 items-center mt-1">
                <input type="text" id="coupon-code" class="border border-gray-300 text-sm text-gray-700 rounded-lg p-1.5 w-full sm:w-3/4 md:w-2/3 focus:outline-none focus:ring-1 focus:ring-green-500" placeholder="Masukkan Kode Kupon" value="<?php echo e($couponCode ?? ''); ?>">
                <button id="apply-coupon" class="bg-green-400 flex text-sm text-white p-1.5 px-3 font-semibold rounded-lg hover:bg-green-300">Gunakan</button>
            </div>

            <!-- Total Harga -->
            <div class="mt-3">
                <div class="flex justify-between items-center flex-wrap gap-2">
                    <h3 class="font-semibold text-gray-700 text-sm">
                        Total:
                    </h3>
                    <div class="flex items-center space-x-2">
                        <?php if($couponCode): ?>
                            <span class="text-gray-500 line-through text-sm">
                                Rp <?php echo e(number_format($totalPrice, 0, ',', '.')); ?>

                            </span>
                        <?php endif; ?>
                        <span id="total-price" class="text-red-500 font-semibold text-sm">
                            Rp <?php echo e(number_format($totalPriceAfterDiscount, 0, ',', '.')); ?>

                        </span>
                    </div>
                </div>

                <!-- Button Beli -->
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isPending = in_array($cart->course_id, $pendingTransactions);
                    ?>

                    <?php if($isPending): ?>
                        <button 
                            class="bg-gray-400 text-white font-semibold py-1.5 px-3 rounded-lg w-full mt-3 text-sm cursor-not-allowed" 
                            onclick="showPendingAlert(event)">
                            Beli Sekarang
                        </button>
                    <?php else: ?>
                        <button 
                            class="bg-green-400 text-white font-semibold py-1.5 px-3 rounded-lg hover:bg-green-300 w-full mt-3 text-sm" 
                            id="pay-now" 
                            data-total-price="<?php echo e($totalPriceAfterDiscount); ?>">
                            Beli Sekarang
                        </button>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    function showPendingAlert(e) {
                        e.preventDefault();
                        Swal.fire({
                            icon: 'info',
                            title: 'Kursus sudah dibeli',
                            text: 'Anda sudah membeli kursus ini. Harap tunggu konfirmasi dari admin.',
                            confirmButtonColor: '#3085d6',
                            confirmButtonText: 'Oke'
                        });
                    }
                </script>      
            
            </div>

         </div>
        </div>
        <?php endif; ?>
    </div>

<!-- Modal Overlay -->
<div id="registration-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
    <!-- Modal Box -->
    <div class="bg-white w-full max-w-md mx-auto rounded-2xl shadow-2xl p-8 relative animate__animated animate__fadeInDown">
        <!-- Tombol Close -->
        <button id="close-modal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-600 text-2xl font-bold">
            &times;
        </button>

        <h3 class="text-2xl font-semibold mb-6 text-gray-800 text-center">Formulir Pendaftaran</h3>

        <form id="wa-form">
            <div class="space-y-4">
                <label class="block">
                    <span class="text-gray-700 font-medium">Nama Lengkap</span>
                    <input id="nama" type="text" class="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-gray-400"
                        value="<?php echo e(Auth::user()->name); ?>" readonly>
                </label>
                <label class="block">
                    <span class="text-gray-700 font-medium">Email</span>
                    <input id="email" type="email" class="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-gray-400"
                        value="<?php echo e(Auth::user()->email); ?>" readonly>
                </label>
                <label class="block">
                    <span class="text-gray-700 font-medium">No Telepon</span>
                    <input id="telepon" type="telp" class="mt-1 block w-full border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-gray-400"
                        value="<?php echo e(Auth::user()->phone_number); ?>" readonly>
                </label>
            </div>

            <!-- Kursus dari keranjang -->
            <?php
                $courseTitles = $carts->pluck('course.title')->toArray();
                $courseList = implode(', ', $courseTitles);
            ?>

            <input type="hidden" id="nama-kursus" value="<?php echo e($courseList); ?>">
            <input type="hidden" id="total-harga" value="Rp <?php echo e(number_format($totalPriceAfterDiscount, 0, ',', '.')); ?>">

            <div class="mt-6 text-gray-700 space-y-1 text-sm">
                <p><strong>Kursus:</strong> <?php echo e($courseList); ?></p>
                <p><strong>Total Harga:</strong> Rp <?php echo e(number_format($totalPriceAfterDiscount, 0, ',', '.')); ?></p>
                <p><strong>No Rekening Admin:</strong> 0895365544316 (Dana/Bank)</p>
            </div>

            <!-- Tombol WhatsApp -->
            <a id="kirim-wa"
               href="#"
               target="_blank"
               class="mt-6 block text-center bg-green-500 hover:bg-green-400 text-white font-semibold py-2 px-4 rounded-lg w-full transition-all duration-200">
                Kirim Bukti Pembayaran via WhatsApp
            </a>
        </form>
    </div>
</div>

<script>
    const payNowBtn = document.getElementById('pay-now');
    const modal = document.getElementById('registration-modal');
    const closeModalBtn = document.getElementById('close-modal');

    payNowBtn.addEventListener('click', function () {
        modal.classList.remove('hidden');
        modal.classList.add('flex'); // agar bisa tampil sebagai flex (centered)
    });

    closeModalBtn.addEventListener('click', function () {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    });

    // Opsional: Tutup modal jika klik di luar box
    window.addEventListener('click', function (e) {
        if (e.target === modal) {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    });

    document.getElementById('kirim-wa').addEventListener('click', function (e) {
        e.preventDefault();

        const nama = document.getElementById('nama')?.value || 'Tidak Ada';
        const email = document.getElementById('email')?.value || 'Tidak Ada';
        const telepon = document.getElementById('telepon')?.value || 'Tidak Ada';
        const kursus = document.getElementById('nama-kursus')?.value || 'Tidak Ada';
        const harga = document.getElementById('total-harga')?.value || '<?php echo e($totalPriceAfterDiscount); ?>';

        const nomorAdmin = <?php echo json_encode($nomorAdmin, 15, 512) ?>; 
        const pesan = `Halo Admin, saya ingin mengkonfirmasi pembayaran untuk:\n\n` +
            `👤 Nama: ${nama}\n📧 Email: ${email}\n📱 Telepon: ${telepon}\n\n` +
            `💻 Kursus: ${kursus}\n💰 Total: Rp ${harga}\n\n` +
            `Saya sudah melakukan pembayaran, berikut bukti transfernya.`;

        const whatsappUrl = `https://wa.me/${nomorAdmin}?text=${encodeURIComponent(pesan)}`;

        fetch(`<?php echo e(route('create-payment')); ?>`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            },
            body: JSON.stringify({
                whatsapp_url: whatsappUrl,
                coupon_code: '<?php echo e($couponCode ?? ''); ?>',
            }),
        })
        .then(response => {
            if (!response.ok) throw new Error('Gagal menyimpan data.');
            return response.json();
        })
        .then(data => {
            if (data.success) {
                window.open(whatsappUrl, '_blank');
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal',
                    text: data.message || 'Gagal menyimpan data ke server.',
                });
            }
        })
        
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Kesalahan',
                text: 'Terjadi kesalahan saat mengirim data.',
            });
        });
    });
     
    document.getElementById('apply-coupon').addEventListener('click', function() {
        let couponCode = document.getElementById('coupon-code').value;
        if (couponCode) {
            window.location.href = "<?php echo e(route('cart.index')); ?>?coupon=" + couponCode;
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Oops!',
                text: 'Masukkan kode kupon terlebih dahulu!',
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-peserta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-peserta/keranjang.blade.php ENDPATH**/ ?>