<?php $__env->startSection('title', 'Edit Kursus'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
    <div class="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700 text-center w-full border-b-2 border-gray-300 pb-2">Edit Kursus</h2>

        <!-- Form Edit Kursus -->
      <form action="<?php echo e(route('courses.update', $course->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
        <!-- Kolom Kiri -->
        <div>
            <!-- Input untuk Judul -->
            <div class="mb-4">
                <label for="title" class="block text-gray-700 font-semibold mb-2">Judul Kursus</label>
                <input type="text" name="title" id="title" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan judul kursus" value="<?php echo e(old('title', $course->title)); ?>">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-title"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input untuk Harga -->
            <div class="mb-3">
                <label for="price" class="block text-gray-700 font-semibold mb-2">Harga</label>
                <input type="text" name="price" id="price" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan harga kursus" value="<?php echo e(old('price', $course->price)); ?>">
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-price"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input untuk Start_date -->
            <div class="mb-4">
                <label for="start_date" class="block text-gray-700 font-semibold mb-2">Tanggal Mulai</label>
                <input type="date" name="start_date" id="start_date" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('start_date', $course->start_date)); ?>">
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-start_date"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input untuk End_date -->
            <div class="mb-4">
                <label for="end_date" class="block text-gray-700 font-semibold mb-2">Tanggal Selesai</label>
                <input type="date" name="end_date" id="end_date" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('end_date', $course->end_date)); ?>">
                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-end_date"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input untuk Deskripsi -->
            <div class="mb-3">
                <label for="description" class="block text-gray-700 font-semibold mb-2">Deskripsi</label>
                <textarea name="description" id="description" rows="6" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan deskripsi kursus"><?php echo e(old('description', $course->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-description"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>

        <!-- Kolom Kanan: Foto -->
        <div>
            <!-- Input untuk Kategori -->
            <div class="mb-4">
                <label for="category_id" class="block text-gray-700 font-semibold mb-2">Kategori Kursus</label>
                <select name="category_id" id="category_id" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">Pilih Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id', $course->category_id) == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-category"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>                             

            <!-- Input untuk Kapasitas -->
            <div class="mt-3">
                <label for="capacity" class="block text-gray-700 font-semibold mb-2">Kapasitas Peserta</label>
                <input type="number" name="capacity" id="capacity" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('capacity', $course->capacity)); ?>">
                <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-capacity"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Menampilkan gambar saat ini jika ada -->
            <?php if($course->image_path): ?>
                <div class="mt-6">
                    <label class="block text-gray-700 font-semibold mb-2">Gambar Saat Ini</label>
                    <img src="<?php echo e(asset('storage/' . $course->image_path)); ?>" alt="<?php echo e($course->name); ?>" class="w-42 h-40 object-cover rounded">
                </div>
            <?php endif; ?>

            <!-- Input untuk Foto -->
            <div class="mb-4">
                <label for="image" class="block text-gray-700 font-semibold mb-2">Unggah Gambar Baru</label>
                <input type="file" name="image" id="image" class="w-full p-2 text-sm text-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 border rounded <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm" id="error-image"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mt-4">
                <label for="chat-toggle" class="flex items-center cursor-pointer">
                    <span class="mr-3 text-gray-700 font-semibold">Aktifkan Fitur Chat</span>
                    <!-- Toggle Switch -->
                    <div class="relative">
                        <input type="checkbox" name="chat" id="chat-toggle" class="hidden peer" <?php echo e(old('chat', $course->chat ?? false) ? 'checked' : ''); ?> value="1"/>
                        <div class="block bg-gray-300 w-9 h-5 rounded-full peer-checked:bg-green-500 peer-checked:justify-end"></div>
                        <div class="dot absolute top-0.5 start-[2px] bg-white h-4 w-4 rounded-full transition-transform peer-checked:translate-x-full"></div>
                    </div>
                </label>
            
                <!-- Pesan saat fitur chat diaktifkan -->
                <div id="chat-status" class="mt-1 hidden">
                    <p class="text-green-500 font-semibold">Fitur Chat Aktif!</p>
                </div>
            
                <!-- Pesan saat fitur chat dinonaktifkan -->
                <div id="chat-status-inactive" class="mt-1 hidden">
                    <p class="text-red-500 font-semibold">Fitur Chat Dinonaktifkan!</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Tombol Submit -->
    <div class="mt-6 flex justify-end space-x-2">
        <a href="<?php echo e(route('courses.index')); ?>" class="bg-red-400 hover:bg-red-300 text-white font-semibold py-2 px-4 rounded-lg">
            Batal
        </a>
        <button type="submit" class="bg-sky-400 hover:bg-sky-300 text-white font-semibold py-2 px-4 rounded-lg">
            Simpan
        </button>
    </div>
</form>
    </div>
</div>

 <script>
        // Menghapus error dan border merah saat pengguna mulai mengetik
        const inputs = document.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                const errorSpan = document.getElementById('error-' + input.id);
                if (errorSpan) {
                    errorSpan.style.display = 'none';  // Sembunyikan pesan error
                }
                input.classList.remove('border-red-500');  // Hapus border merah
            });
        });
        
        // Ambil elemen toggle dan pesan status
        const chatToggle = document.getElementById('chat-toggle');
        const chatStatus = document.getElementById('chat-status');
        const chatStatusInactive = document.getElementById('chat-status-inactive');

        // Fungsi untuk menampilkan atau menyembunyikan pesan berdasarkan status toggle
        function updateChatStatus() {
            if (chatToggle.checked) {
                chatStatus.classList.remove('hidden');
                chatStatusInactive.classList.add('hidden');
            } else {
                chatStatus.classList.add('hidden');
                chatStatusInactive.classList.remove('hidden');
            }
        }

        // Menampilkan status berdasarkan keadaan toggle saat pertama kali dimuat
        window.addEventListener('DOMContentLoaded', () => {
            updateChatStatus();  // Panggil fungsi untuk set status saat halaman pertama kali dimuat
        });

        // Menambahkan event listener untuk toggle
        chatToggle.addEventListener('change', function() {
            updateChatStatus();  // Panggil fungsi untuk set status saat toggle berubah
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-mentor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-mentor/kursus-edit.blade.php ENDPATH**/ ?>