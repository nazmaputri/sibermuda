<?php $__env->startSection('title', 'Tambah Kuis'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
    <div class="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <!-- Judul Halaman -->
        <h2 class="text-xl font-semibold text-gray-700 text-center w-full border-b-2 border-gray-300 pb-2">Tambah Kuis</h2>

        

        <!-- Form Tambah Kuis -->
        <form action="<?php echo e(route('quiz.store', ['courseId' => $courseId])); ?>" method="POST" class="space-y-6">    
    <?php echo csrf_field(); ?>
    <!-- Input untuk Judul Kuis -->
     <div>
        <label for="title" class="block text-gray-700 font-semibold mb-2">Judul Kuis</label>
        <input type="text" name="title" id="title" class="w-full p-2 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 text-gray-600 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan judul kuis" value="<?php echo e(old('title')); ?>">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-600 text-sm mt-1 error-message" id="error-title"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Input untuk Deskripsi Kuis -->
    <div>
        <label for="description" class="block text-gray-700 font-semibold mb-2">Deskripsi</label>
        <textarea name="description" id="description" rows="5" class="w-full p-2 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 text-gray-600 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan deskripsi kuis"><?php echo e(old('description')); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-600 text-sm mt-1 error-message" id="error-description"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Input untuk Waktu Pengerjaan Kuis -->
    <div>
        <label for="duration" class="block text-gray-700 font-semibold mb-2">Durasi (menit)</label>
        <input type="number" name="duration" id="duration" class="w-full p-2 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 text-gray-600 <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan durasi kuis (menit)" value="<?php echo e(old('duration')); ?>" min="1">
        <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-600 text-sm mt-1 error-message" id="error-duration"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <!-- Daftar Soal Dinamis -->
    <div id="questions-container">
        <h3 class="text-md font-semibold mb-1 text-gray-700">Soal dan Jawaban</h3>

        <!-- Soal Template (untuk cloning) -->
        <template id="question-template">
            <div class="question-item border p-4 mb-4 rounded bg-white">
                <!-- Menampilkan Nomor Soal -->
                <div class="mb-3">
                    <span class="text-md text-gray-700 font-semibold">Soal <span class="question-number"></span></span>
                </div>

                <!-- Input Pertanyaan -->
                <div class="mb-3">
                    <label class="block text-gray-700 font-semibold mb-2">Soal</label>
                    <input type="text" name="questions[0][question]" class="w-full p-2 border rounded question-input focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 text-gray-600" placeholder="Masukkan teks soal" value="<?php echo e(old('questions.0.question')); ?>" >
                    <?php $__errorArgs = ['questions.*.question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Input Jawaban Pilihan Ganda -->
                <div class="answers-container">
                    <label class="block text-gray-700 font-semibold mb-2">Jawaban Pilihan Ganda</label>
                    <?php for($i = 0; $i < 4; $i++): ?>
                        <div class="flex items-center mb-2">
                            <input type="radio" name="questions[0][correct_answer]" value="<?php echo e($i); ?>" class="mr-2 answer-radio" >
                            <input type="text" name="questions[0][answers][]" class="w-full text-gray-600 p-2 border focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 rounded answer-input" placeholder="Masukkan jawaban" value="<?php echo e(old('questions.0.answers.' . $i)); ?>" >
                            <?php $__errorArgs = ['questions.*.answers.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endfor; ?>
                </div>

                <!-- Tombol Hapus Soal -->
                <button type="button" onclick="removeQuestion(this)" class="text-red-600 hover:text-red-800 font-semibold mt-2">Hapus Soal</button>
            </div>
        </template>

        <!-- Container untuk Soal-soal -->
        <div id="question-list"></div>

        <!-- Tombol Tambah Soal -->
        <button type="button" onclick="addQuestion()" class="mt-1 bg-green-400 hover:bg-green-300 text-white font-semibold py-2 px-4 text-sm rounded">
            Tambah Soal
        </button>
    </div>

    <!-- Tombol Submit -->
    <div class="mt-6 flex justify-end space-x-2">
            
            <a href="<?php echo e(route('courses.show', ['course' => $course->id])); ?>"
            class="bg-red-400 hover:bg-red-300 text-white font-semibold py-2 px-4 rounded-md">
                Batal
            </a>
        <button type="submit" class="bg-sky-400 hover:bg-sky-300 text-white font-semibold py-2 px-4 rounded-md">
            Simpan
        </button>
    </div>
</form>

        
    </div>
</div>

<script>
// Fungsi untuk menghapus pesan error dan border merah saat pengguna mulai mengetik
    document.addEventListener('DOMContentLoaded', function () {
        // Mengambil semua input dan textarea yang memiliki error
        const inputs = document.querySelectorAll('input, textarea');
        
        inputs.forEach(input => {
            input.addEventListener('input', function () {
                // Hapus border merah dan pesan error ketika pengguna mulai mengetik
                if (this.classList.contains('border-red-500')) {
                    this.classList.remove('border-red-500');
                }
                const errorMessage = document.querySelector(`#error-${this.id}`);
                if (errorMessage) {
                    errorMessage.remove();
                }
            });
        });
    });

    let questionCounter = 0;

    function addQuestion() {
        const template = document.getElementById('question-template').content.cloneNode(true);
        const questionList = document.getElementById('question-list');
        const newIndex = questionCounter++;

        template.querySelector('.question-number').textContent = newIndex + 1;

        template.querySelectorAll('.question-input, .answer-input, .answer-radio').forEach(el => {
            if (el.classList.contains('question-input')) {
                el.name = `questions[${newIndex}][question]`;
            } else if (el.classList.contains('answer-radio')) {
                el.name = `questions[${newIndex}][correct_answer]`;
            } else {
                el.name = `questions[${newIndex}][answers][]`;
            }
        });

        questionList.appendChild(template);
    }

    function removeQuestion(element) {
        element.closest('.question-item').remove();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-mentor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-mentor/quiz-create.blade.php ENDPATH**/ ?>