<?php $__env->startSection('title', 'Detail Kursus'); ?>
<?php $__env->startSection('content'); ?>

<!-- Tombol Kembali -->
<div class="flex justify-start mb-2">
    <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="text-midnight font-semibold p-1 bg-white border border-gray-200 rounded-full transition-transform duration-300 ease-in-out transform hover:scale-105 inline-flex items-center">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
        </svg>
    </a>
</div>

<div class="bg-white p-6 rounded-lg shadow-md border border-gray-200">
    <!-- Card Informasi Kursus -->
    <div class="flex flex-col lg:flex-row mb-4">
        <div class="w-full lg:w-1/3 mb-4 lg:mb-0">
            <img src="<?php echo e(asset('storage/' . $course->image_path)); ?>" alt="<?php echo e($course->title); ?>" class="rounded-lg w-80 h-35">
        </div>
        <!-- Informasi Kursus -->
        <div class="ml-4 w-2/3 md:ml-4 mt-1 space-y-1">
            <h2 class="text-md font-semibold text-gray-700 mb-2 capitalize"><?php echo e($course->title); ?></h2>
            <p class="text-gray-700 mb-2 text-sm"><?php echo e($course->description); ?></p>
            <p class="text-gray-600 text-sm">Mentor : <span class="capitalize"><?php echo e($course->mentor->name); ?><span></p>
            <p class="text-gray-600 text-sm">Harga : <span class="text-red-500">Rp <?php echo e(number_format($course->price, 0, ',', '.')); ?></span></p>
            <p class="text-gray-600 text-sm">Kapasitas : <?php echo e($course->capacity); ?> peserta</p> 
            <p class="text-gray-600 text-sm">Tanggal Mulai : <?php echo e($course->start_date); ?></p>
            <p class="text-gray-600 text-sm">Masa Aktif : <?php echo e($course->duration); ?></p>
        </div>
    </div>

    <!-- Silabus -->
    <div class="mt-10">
        <h3 class="text-lg font-semibold text-gray-700 mb-6 border-b-2 border-gray-300 pb-2">Materi Kursus</h3>
        <div class="space-y-6">
            <?php if($course->materi->isEmpty()): ?>
                <p class="text-gray-600 text-center mt-1 text-sm">Kursus ini belum ada materi apapun.</p>
            <?php else: ?>
            <?php $__currentLoopData = $course->materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white border border-gray-200 p-4 rounded-lg shadow-sm">
                <div x-data="{ open: false }">
                    <!-- Judul Materi dengan Toggle Dropdown -->
                    <div @click="open = !open" class="flex justify-between items-center cursor-pointer">
                        <!-- Menambahkan nomor urut di sebelah kiri judul -->
                        <span class="text-gray-700 font-semibold mr-2">
                            <?php echo e(sprintf('%02d', $loop->iteration)); ?>.
                        </span>
                        
                        <h4 class="text-md font-semibold text-gray-700 flex-1 capitalize"><?php echo e($materi->judul); ?></h4>
                                                
                        <!-- Tombol Toggle -->
                        <svg :class="open ? 'transform rotate-180' : ''" class="w-5 h-5 text-gray-600 transition-transform" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </div>

                    <!-- Deskripsi Materi -->
                    <p class="text-gray-600 mb-2 mt-2" x-show="open" x-transition><?php echo e($materi->deskripsi); ?></p>

                    <!-- Video (Tampilkan hanya jika open adalah true) -->
                    <div x-show="open" x-transition>
                        <?php if($materi->videos->isEmpty() && $materi->youtube->isEmpty()): ?>
                        <p class="text-gray-700">Tidak ada video untuk materi ini.</p>
                        <?php else: ?>
                            <ul class="mt-4 space-y-4">
                                
                                <?php $__currentLoopData = $materi->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="bg-gray-100 p-4 rounded-lg shadow-sm">
                                        <h3 class="font-semibold text-gray-800"><?php echo e($video->title); ?></h3>
                                        <p class="text-gray-600"><?php echo e($video->description ?: 'Tidak ada deskripsi video'); ?></p>
            
                                        <?php if($video->link): ?>
                                            <iframe
                                                src="https://drive.google.com/file/d/<?php echo e($video->link); ?>/preview"
                                                width="100%" height="480"
                                                allow="autoplay"
                                                allowfullscreen
                                                class="rounded-lg shadow-md">
                                            </iframe>
                                        <?php else: ?>
                                            <p class="text-red-500">Video Google Drive tidak tersedia.</p>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                                
                                <?php $__currentLoopData = $materi->youtube; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="bg-gray-100 p-4 rounded-lg shadow-sm">
                                        <h3 class="font-semibold text-gray-800"><?php echo e($yt->title); ?></h3>
                                        <p class="text-gray-600"><?php echo e($yt->description ?: 'Tidak ada deskripsi video'); ?></p>
            
                                        <?php if($yt->link): ?>
                                            <iframe
                                                width="100%" height="480"
                                                src="https://www.youtube.com/embed/<?php echo e($yt->link); ?>"
                                                frameborder="0"
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                allowfullscreen
                                                class="rounded-lg shadow-md">
                                            </iframe>
                                        <?php else: ?>
                                            <p class="text-red-500">Video YouTube tidak tersedia.</p>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    <?php endif; ?>                             
                    </div>

                    <!-- Kuis -->
                    <div x-show="open" x-transition>
                        
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>

    <!-- Tabel Peserta Terdaftar -->
    <div class="bg-white mt-6 p-6 rounded-lg shadow-md border border-gray-200">
        <h3 class="text-lg font-semibold mb-4 inline-block pb-1 text-gray-700">Peserta Terdaftar</h3>
            <div class="overflow-x-auto">
                <div class="min-w-full w-64">
                <table class="min-w-full border-separate border-spacing-0" id="courseTable">
                    <thead>
                        <tr class="bg-gray-100 text-gray-600 text-sm">
                            <th class="py-2 px-2 border-b border-l border-t border-gray-200  rounded-tl-lg">No</th>
                            <th class="py-2 px-4 border-b border-t border-gray-200">Nama</th>
                            <th class="py-2 px-4 border-b border-t border-gray-200">Email</th>
                            <th class="py-2 border-b border-r border-t border-gray-200  rounded-tr-lg">Status Pembayaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="bg-white hover:bg-gray-50 user-row text-sm">
                            <td class="py-2 px-4 text-center text-gray-600 text-sm border-b border-l border-gray-200"><?php echo e($index + 1); ?></td>
                            <td class="py-2 px-4 text-gray-600 text-sm border-b border-gray-200"><?php echo e($participant->user->name); ?></td>
                            <td class="py-2 px-4 text-gray-600 text-sm border-b border-gray-200"><?php echo e($participant->user->email); ?></td>
                            <td class="py-2 text-center text-green-500 text-sm border-b border-r border-gray-200"><?php echo e($participant->transaction_status); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="py-2 text-center text-sm text-gray-600 border-l border-b border-r border-gray-200">Belum ada peserta terdaftar.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                </div>
                <div class="mt-4">
                    <?php echo e($participants->links()); ?>

                </div>
            </div> 
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-admin/detail-kursus.blade.php ENDPATH**/ ?>