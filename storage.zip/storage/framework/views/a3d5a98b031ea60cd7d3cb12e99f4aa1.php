<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\kursus-sibermuda\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>