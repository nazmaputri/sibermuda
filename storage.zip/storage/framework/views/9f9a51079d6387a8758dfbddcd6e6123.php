<?php $__env->startSection('content'); ?>

<div class="mb-3 flex justify-start">
    <a href="<?php echo e(route('courses.show', ['course' => $course->id])); ?>" class="text-midnight font-semibold p-1 bg-white border border-gray-200 rounded-full transition-transform duration-300 ease-in-out transform hover:scale-105">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
        </svg>
    </a>
</div>

<div class="container mx-auto">
    <!-- Card Wrapper untuk Kuis -->
    <div class="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
        <!-- Judul Kuis -->
        <h1 class="text-xl text-gray-700 text-center font-semibold mb-3 border-b-2 pb-2 capitalize"><?php echo e($quiz->title); ?></h1>

        <!-- Deskripsi Kuis -->
        <p class="text-gray-700 mb-2 text-md">
            <?php echo e($quiz->description ?? 'Tidak ada deskripsi untuk kuis ini.'); ?>

        </p>

        <!-- Durasi Kuis -->
        <p class="text-gray-600 mb-6 text-sm">
            <strong>Durasi :</strong> <?php echo e($quiz->duration); ?> Menit
        </p>

        <!-- Daftar Soal -->
        <?php if($quiz->questions->isNotEmpty()): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm">
            <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Card untuk Setiap Soal -->
            <div class="bg-gray-50 border rounded-lg p-4 shadow-md text-sm">
                <div class="flex items-start">
                    <!-- Nomor Soal -->
                    <span class="text-sm text-gray-700 font-semibold mr-2"><?php echo e($index + 1); ?>.</span>
                    
                    <!-- Pertanyaan -->
                    <p class="text-sm font-medium text-gray-700 flex-1 capitalize"><?php echo e($question->question); ?></p>
                </div>

                <!-- Jawaban Tersembunyi dengan Dropdown -->
                <details class="mt-4">
                    <summary class="cursor-pointer text-sky-400">Lihat Jawaban</summary>
                    <ul class="list-none mt-2 space-y-2">
                        <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="p-2 border rounded-md <?php echo e($answer->is_correct ? 'bg-green-100 text-green-700 font-semibold' : 'bg-gray-100 text-gray-600'); ?>">
                            <?php echo e($answer->answer); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </details>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <p class="text-gray-500">Belum ada soal yang ditambahkan untuk kuis ini.</p>
        <?php endif; ?>

        <!-- Tombol Kembali -->
        <!-- <div class="mt-6 justify-end flex">
            <?php if(isset($materiId)): ?>
                
                <a href="<?php echo e(route('materi.show', ['courseId' => $course->id, 'materiId' => $materi->id])); ?>"
                class="bg-sky-400 hover:bg-sky-300 text-white font-semibold py-2 px-4 rounded-lg">
                    Kembali
                </a>
            <?php else: ?>
                
                <a href="<?php echo e(route('courses.show', ['course' => $course->id])); ?>"
                class="bg-sky-400 hover:bg-sky-300 text-white font-semibold py-2 px-4 rounded-lg">
                    Kembali
                </a>
            <?php endif; ?>
        </div> -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-mentor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-mentor/quiz-detail.blade.php ENDPATH**/ ?>