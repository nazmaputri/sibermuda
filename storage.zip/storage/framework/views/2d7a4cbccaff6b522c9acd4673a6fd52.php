

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <!-- Final Task Detail -->
    <div class="bg-white rounded-2xl shadow p-6 mb-8">
        <h1 class="text-2xl font-bold mb-4">Detail Tugas Akhir</h1>
        <div class="space-y-2">
            <p><span class="font-semibold">Judul:</span> <?php echo e($finalTask->judul); ?></p>
            <p><span class="font-semibold">Deskripsi:</span> <?php echo e($finalTask->desc); ?></p>
        </div>
    </div>

    <!-- Table: Peserta yang sudah mengumpulkan -->
    <div class="bg-white rounded-2xl shadow p-6 mb-8">
        <h2 class="text-xl font-semibold mb-4">Peserta yang Telah Mengumpulkan</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">No</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Nama</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Judul</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Deskripsi</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Foto</th>
                        <th class="px-4 py-2 text-center text-sm font-medium text-gray-700">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-4 py-2"><?php echo e($index + 1); ?></td>
                        <td class="px-4 py-2"><?php echo e($submission->user->name); ?></td>
                        <td class="px-4 py-2"><?php echo e($submission->title); ?></td>
                        <td class="px-4 py-2"><?php echo e(Str::limit($submission->description, 50)); ?></td>
                        <td class="px-4 py-2">
                            <?php if($submission->photo): ?>
                                <img src="<?php echo e(Storage::url($submission->photo)); ?>" alt="Foto Tugas" class="h-16 w-16 object-cover rounded" />
                            <?php else: ?>
                                <span class="text-gray-400 text-sm">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 text-center">
                            <?php if($submission->certificate_status == 'pending'): ?>
                                <form action="<?php echo e(route('final-task.confirm', $submission->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit">Konfirmasi Sertifikat</button>
                                </form>
                            <?php elseif($submission->certificate_status == 'approved'): ?>
                                <span class="text-green-600 font-medium">Disetujui</span>
                            <?php else: ?>
                                <span class="text-gray-500">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-mentor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-mentor/finaltask-detail.blade.php ENDPATH**/ ?>