<nav role="navigation" aria-label="Pagination Navigation" class="flex justify-end mt-4">
    <ul class="inline-flex items-center space-x-1 text-sm">

        
        <?php if($paginator->onFirstPage()): ?>
            <li class="px-3 py-1 bg-gray-200 text-gray-700 rounded">‹</li>
        <?php else: ?>
            <li>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100">‹</a>
            </li>
        <?php endif; ?>

        
        <?php
            $currentPage = $paginator->currentPage();
            $lastPage = $paginator->lastPage();
            $start = max($currentPage - 1, 1);
            $end = min($currentPage + 1, $lastPage);
        ?>

        <?php for($i = $start; $i <= $end; $i++): ?>
            <?php if($i == $currentPage): ?>
                <li class="px-3 py-1 bg-white border border-midnight text-midnigh rounded"><?php echo e($i); ?></li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e($paginator->url($i)); ?>" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100 text-gray-700"><?php echo e($i); ?></a>
                </li>
            <?php endif; ?>
        <?php endfor; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-100">›</a>
            </li>
        <?php else: ?>
            <li class="px-3 py-1 bg-gray-200 text-gray-500 rounded">›</li>
        <?php endif; ?>

    </ul>
</nav>
<?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>