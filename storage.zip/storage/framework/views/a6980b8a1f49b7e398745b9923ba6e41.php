<?php $__env->startSection('title', 'Tambah Kursus'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mx-auto"> 
    <div class="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700 text-center w-full border-b-2 border-gray-300 pb-2">Tambah Kursus</h2>

        <!-- Form Tambah Kursus -->
        <form action="<?php echo e(route('courses.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                <!-- Kolom Kiri -->
                <div>
                    <!-- Input untuk Judul -->
                    <div class="mb-4">
                        <label for="title" class="block font-semibold text-gray-700 pb-2">Judul Kursus</label>
                        <input type="text" name="title" id="title" class="w-full p-2 text-sm text-gray-700 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan judul kursus" value="<?php echo e(old('title')); ?>">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Input untuk Start_date -->
                    <div class="mb-4">
                        <label for="start_date" class="block font-semibold text-gray-700 pb-2">Tanggal Mulai</label>
                        <input type="date" name="start_date" id="start_date" class="w-full p-2 text-sm text-gray-700 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan Waktu Mulai" min="<?php echo e(\Carbon\Carbon::today()->toDateString()); ?>">
                        <small class="text-gray-600">Jika tidak di isi maka "Akses seumur hidup"</small>
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Input untuk End_date -->
                    <div class="mb-4">
                        <label for="end_date" class="block font-semibold text-gray-700 pb-2">Tanggal Selesai</label>
                        <input type="date" name="end_date" id="end_date" class="w-full p-2 text-sm text-gray-700 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan Waktu Selesai" min="<?php echo e(\Carbon\Carbon::today()->toDateString()); ?>">
                        <small class="text-gray-600">Jika tidak di isi maka "Akses seumur hidup"</small>
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Input untuk Deskripsi -->
                    <div class="mb-1">
                        <label for="description" class="block font-semibold text-gray-700 pb-2">Deskripsi</label>
                        <textarea name="description" id="description" rows="4" class="w-full p-2 text-sm text-gray-700 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan deskripsi kursus"><?php echo e(old('description')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <!-- Kolom Kanan -->
                <div>
                    <!-- Input untuk Kategori -->
                    <div x-data="{ open: false, selected: '', selectedId: '', categories: <?php echo \Illuminate\Support\Js::from($categories)->toHtml() ?> }" class="relative mb-4">
                        <label for="category_id" class="block font-semibold text-gray-700 pb-2">Kategori Kursus</label>

                        <!-- Display Selected -->
                        <button @click="open = !open" type="button"
                            class="w-full p-2 text-sm text-left text-gray-700 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400">
                            <span x-text="selected || 'Pilih Kategori'"></span>
                        </button>

                        <!-- Dropdown List -->
                        <div x-show="open" @click.away="open = false"
                            class="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded shadow max-h-48 overflow-y-auto text-sm scrollbar-hide text-gray-700"
                            style="display: none;">
                            <template x-for="category in categories" :key="category.id">
                                <div @click="selected = category.name; selectedId = category.id; open = false"
                                    class="cursor-pointer px-4 py-2 hover:bg-gray-100"
                                    :class="{ 'bg-gray-100': selectedId === category.id }">
                                    <span x-text="category.name"></span>
                                </div>
                            </template>
                        </div>

                        <!-- Hidden Input to Submit -->
                        <input type="hidden" name="category_id" :value="selectedId">

                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-600 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Input untuk Harga -->
                    <div class="mb-4">
                        <label for="price" class="block font-semibold text-gray-700 pb-2">Harga</label>
                        <input type="text" name="price" id="price" class="w-full p-2 text-sm text-gray-700 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan harga kursus.contoh:3000 " value="<?php echo e(old('price')); ?>">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Input untuk Kapasitas -->
                    <div class="mb-4">
                        <label for="capacity" class="block font-semibold text-gray-700 pb-2">Kapasitas Peserta</label>
                        <input type="number" name="capacity" id="capacity" class="w-full p-2 text-sm text-gray-700 border rounded focus:outline-none focus:ring-1 focus:ring-gray-400 focus:border-gray-400 <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan kapasitas kursus" value="<?php echo e(old('capacity')); ?>">
                        <small class="text-gray-600">Jika tidak di isi maka kapasitasnya tidak terbatas</small>
                        <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Input untuk Foto -->
                    <div class="mb-4">
                        <label for="image" class="block font-semibold text-gray-700 pb-2">Foto Kursus</label>
                        <input type="file" name="image" id="image" class="w-full p-2 text-sm text-gray-700 border rounded">
                        <small class="text-gray-600">Format gambar yang diperbolehkan: jpg, png, jpeg</small>
                    </div>
                    
                    <div class="mt-4">
                        <label for="chat-toggle" class="flex items-center cursor-pointer">
                            <span class="mr-3 text-gray-700 font-semibold">Aktifkan Fitur Chat</span>
                            <!-- Toggle Switch -->
                            <div class="relative ">
                                <input type="checkbox" name="chat" id="chat-toggle" class="hidden peer" <?php echo e(old('chat', $course->chat ?? false) ? 'checked' : ''); ?> value="1"/>
                                <div class="block bg-gray-300 w-9 h-5 rounded-full peer-checked:bg-green-500 peer-checked:justify-end"></div>
                                <div class="dot absolute top-0.5 start-[2px] bg-white w-4 h-4 rounded-full transition-transform peer-checked:translate-x-full"></div>
                            </div>
                        </label>
                    
                        <!-- Pesan saat fitur chat diaktifkan -->
                        <div id="chat-status" class="mt-1 hidden">
                            <p class="text-green-500 font-semibold">Fitur Chat Aktif!</p>
                        </div>
                    
                        <!-- Pesan saat fitur chat dinonaktifkan -->
                        <div id="chat-status-inactive" class="mt-1 hidden">
                            <p class="text-red-500 font-semibold">Fitur Chat Dinonaktifkan!</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tombol Submit -->
            <div class="mt-6 flex justify-end space-x-2">
                <a href="<?php echo e(route('courses.index')); ?>" class="bg-red-400 hover:bg-red-300 text-white font-bold py-2 px-4 rounded-md">
                    Batal
                </a>
                <button type="submit" class="bg-sky-400 hover:bg-sky-300 text-white font-bold py-2 px-4 rounded-md">
                    Tambah 
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    // Menambahkan event listener untuk toggle
    document.getElementById('chat-toggle').addEventListener('change', function() {
        var chatStatus = document.getElementById('chat-status');
        var chatStatusInactive = document.getElementById('chat-status-inactive');
                    
        // Menampilkan atau menyembunyikan pesan berdasarkan status toggle
        if (this.checked) {
            chatStatus.classList.remove('hidden');
            chatStatusInactive.classList.add('hidden');
        } else {
            chatStatus.classList.add('hidden');
            chatStatusInactive.classList.remove('hidden');
        }
    });
    // Menambahkan event listener untuk setiap input yang ada
    const inputs = document.querySelectorAll('input, textarea, select');

    inputs.forEach(input => {
        input.addEventListener('input', function() {
            // Menghapus kelas border merah saat input mulai diubah
            if (this.classList.contains('border-red-500')) {
                this.classList.remove('border-red-500');
            }

            // Menghapus pesan error jika ada
            const errorMessage = this.nextElementSibling;
            if (errorMessage && errorMessage.classList.contains('text-red-500')) {
                errorMessage.style.display = 'none';
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-mentor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/dashboard-mentor/kursus-create.blade.php ENDPATH**/ ?>