<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/jpg" href="storage/logo.png">
    <title><?php echo e($course->judul ?? 'Kursus'); ?></title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap" rel="stylesheet">
    <!-- AlphineJs -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <!-- AOS CSS -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
     <!-- Custom Style -->
     <style>
        body {
            font-family: "Quicksand", sans-serif !important;
        }
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
    </style>
</head>
<body>
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    
    <?php if($discount && now()->lt($end_datetime)): ?>
        <section id="promo" class="bg-red-600 text-white px-4 py-2 text-center pt-[90px] fixed w-full z-40">
            <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 pb-3 mx-14">
                <!-- Promo text -->
                <div class="text-sm sm:text-base font-semibold">
                    Promo Diskon <?php echo e($discount->discount_percentage); ?>%! <br class="md:hidden" />
                    <span class="font-normal">Berlaku sampai <?php echo e(\Carbon\Carbon::parse($discount->end_date)->format('d F Y')); ?>!</span>
                </div>

                <!-- Countdown -->
                <div class="flex items-center gap-2 text-sm sm:text-base font-bold" id="countdown">
                    <span><span id="days">00</span><span class="text-xs font-normal ml-1">Hari</span></span>
                    <span><span id="hours">00</span><span class="text-xs font-normal ml-1">Jam</span></span>
                    <span><span id="minutes">00</span><span class="text-xs font-normal ml-1">Menit</span></span>
                    <span><span id="seconds">00</span><span class="text-xs font-normal ml-1">Detik</span></span>
                </div>

                <!-- Kode Promo -->
                <div class="flex items-center gap-2">
                    <button class="bg-white text-red-600 font-bold px-3 py-1 rounded hover:bg-gray-100 text-sm">
                        <?php echo e($discount->coupon_code); ?>

                    </button>
                    <button class="bg-sky-500 text-white font-semibold px-3 py-1 rounded hover:bg-sky-400 text-sm"
                        onclick="copyToClipboard('<?php echo e($discount->coupon_code); ?>')">
                        SALIN
                    </button>
                </div>
            </div>
        </section>

        <!-- JavaScript: Countdown & Hide Section When Done -->
        <script>
            const endDateTime = new Date("<?php echo e($end_datetime->format('Y-m-d H:i:s')); ?>").getTime();

            const countdownInterval = setInterval(() => {
                const now = new Date().getTime();
                const distance = endDateTime - now;

                if (distance < 0) {
                    clearInterval(countdownInterval);
                    const promoSection = document.getElementById("promo");
                    if (promoSection) {
                        promoSection.style.display = "none"; // Hilangkan section
                    }
                    return;
                }

                const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                document.getElementById("days").textContent = String(days).padStart(2, '0');
                document.getElementById("hours").textContent = String(hours).padStart(2, '0');
                document.getElementById("minutes").textContent = String(minutes).padStart(2, '0');
                document.getElementById("seconds").textContent = String(seconds).padStart(2, '0');
            }, 1000);

            function copyToClipboard(text) {
                navigator.clipboard.writeText(text).then(function () {
                    alert('Kode promo berhasil disalin: ' + text);
                });
            }
        </script>
    <?php endif; ?>
    
    <!-- Bagian Materi Kursus -->
    <section id="course" class="py-12 bg-[#08072a]">
        <div class="container mx-auto px-6 lg:px-8 md:mt-32 mt-64">
            <!-- Kontainer Kursus -->
            <div class="flex flex-col lg:flex-row bg-white shadow-lg overflow-hidden border rounded-xl">
                <!-- Detail Kursus -->
                <div class="lg:w-2/3 w-full flex flex-col rounded-xl p-8 text-left">
                    <div>
                        <h2 class="md:text-xl text-md font-semibold text-gray-700 capitalize mb-1 capitalize"><?php echo e($course->title); ?></h2>
                        <p class="text-gray-700"><?php echo e($course->description); ?></p>
                        <p class="text-gray-600 capitalize">Mentor : <?php echo e($course->mentor->name); ?></p>
                        <h3 class="text-xl font-semibold text-gray-700 my-2 text-left">Materi</h3>
                        <ul class="divide-y divide-gray-200">
                            <?php $__currentLoopData = $course->materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex items-center space-x-4 py-2">
                                    <!-- Icon -->
                                    <svg class="h-5 w-5 text-gray-700" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512">
                                        <path d="..." />
                                    </svg>
                                    <!-- Judul Materi -->
                                    <span class="text-sm font-semibold text-gray-700 capitalize">
                                        <?php echo e($index + 1); ?>. <?php echo e($materi->judul); ?>

                                    </span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <a href="/">
                            <button class="bg-[#08072a] hover:bg-white hover:text-gray-700 hover:border-2 hover:border-gray-700 text-white py-2 px-4 rounded-full font-semibold mt-6 transition-all">
                                Kembali
                            </button>                            
                        </a>
                    </div>
                </div>

               <!-- Trailer dan keranjang -->
                <div class="lg:w-1/3 w-full h-full p-6 bg-white border border-gray-300 rounded-lg shadow-md" data-aos="zoom-in">
                    <!-- Cuplikan Video Pembelajaran -->
                    <div>
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">Cuplikan Video Pembelajaran</h3>
                    
                        <?php $__currentLoopData = $course->materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($materi->is_preview): ?>
                                <?php
                                    // Coba ambil video Google Drive (MateriVideo)
                                    $driveVid = $materi->videos->first();
                                    // Kalau gak ada, ambil video YouTube
                                    $ytVid    = $materi->youtube->first();
                                ?>
                    
                                <div class="mb-6">
                                    <?php if($driveVid && $driveVid->link): ?>
                                        
                                        <iframe
                                            src="https://drive.google.com/file/d/<?php echo e($driveVid->link); ?>/preview"
                                            width="100%" height="100%"
                                            allow="autoplay"
                                            allowfullscreen
                                            class="rounded-lg shadow-md">
                                        </iframe>
                    
                                    <?php elseif($ytVid && $ytVid->link): ?>
                                        
                                        <iframe
                                            width="100%" height="100%"
                                            src="https://www.youtube.com/embed/<?php echo e($ytVid->link); ?>"
                                            frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                            allowfullscreen
                                            class="rounded-lg shadow-md">
                                        </iframe>
                    
                                    <?php else: ?>
                                        <p class="text-gray-500">Tidak ada video preview untuk materi ini.</p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>                    

                    <!-- Header 3 Teks Sejajar -->
                    <div class="flex space-x-1 items-center mb-4">
                        <?php if($discount && $discountPercentage > 0 && now()->lt($end_datetime)): ?>
                            <span class="font-semibold text-2xl text-gray-700">
                                Rp.<?php echo e(number_format($discountedPrice, 0, ',', '.')); ?>

                            </span>
                            <span class="text-sm font-medium text-gray-600 line-through">
                                Rp.<?php echo e(number_format($originalPrice, 0, ',', '.')); ?>

                            </span>
                            <span class="text-sm font-medium text-gray-600">
                                Potongan <?php echo e($discountPercentage); ?>%!
                            </span>
                        <?php else: ?>
                            <span class="font-semibold text-2xl text-gray-700">
                                Rp.<?php echo e(number_format($originalPrice, 0, ',', '.')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <!-- Countdown Diskon -->
                    <?php if($discount && $end_datetime && now()->lt($end_datetime)): ?>
                        <?php
                            $remaining = \Carbon\Carbon::now()->diff($end_datetime);
                        ?>
                        <div class="flex items-center space-x-1 text-red-500 text-sm mb-6">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
                            </svg>
                            <span>
                                Diskon berlaku <span class="font-semibold">
                                    <?php echo e($remaining->d); ?> Hari <?php echo e($remaining->h); ?> Jam <?php echo e($remaining->i); ?> Menit lagi!
                                </span>
                            </span>
                        </div>
                    <?php endif; ?>

                    <!-- Dua Tombol Vertikal -->
                    <div class="flex flex-col gap-3">
                        <a href="<?php echo e(route('beli.kursus', ['id' => $course->id])); ?>">
                            <button class="w-full bg-[#08072a] hover:bg-white hover:text-[#08072a] border hover:border-[#08072a] text-white font-semibold py-2 px-4 rounded-lg">
                                Tambah Ke Keranjang
                            </button>
                        </a>
                        <a href="<?php echo e(route('beli.kursus', ['id' => $course->id])); ?>">
                            <button class="w-full bg-white border border-[#08072a] hover:bg-[#08072a] hover:text-white text-[#08072a] font-semibold py-2 px-4 rounded-lg transition-all duration-300">
                                Beli Sekarang
                            </button>
                        </a>
                    </div>                    
                </div>
            </div>
        </div>        
    </section>

    <!-- Informasi Kursus -->
    <section class="bg-white p-10">        
        <div class="flex items-center justify-center px-4">
            <div class="w-full text-center">
                <h2 class="text-2xl font-semibold text-gray-700 mb-2" data-aos="zoom-in">
                    Yuk Beli Kursusnya Sekarang Untuk Akses Materinya!
                </h2>
                <!-- Deskripsi -->
                <p class="text-gray-700 mb-6 px-6 lg:px-20" data-aos="zoom-in">
                    Mari belajar di Sibermuda dan mulai tingkatkan skillmu! Pilih kursus yang kamu butuhkan, 
                    pelajari kapan saja, di mana saja. Nikmati video pembelajaran terstruktur dan modul praktik interaktif yang dirancang oleh para ahli di bidangnya.
                </p>
                

                <!-- Pop-up Error jika sudah dibeli -->
                <?php if(session('error')): ?>
                    <div id="popupError" class="fixed top-5 right-5 bg-red-500 text-white px-6 py-4 rounded-lg shadow-lg z-50 animate-bounce">
                        <?php echo e(session('error')); ?>

                    </div>

                    <script>
                        // Hilangkan popup setelah 3 detik
                        setTimeout(function() {
                            const popup = document.getElementById('popupError');
                            if (popup) popup.remove();
                        }, 3000);
                    </script>
                <?php endif; ?>
            </div>
        </div>       
        
        <div class="mt-8 pt-6 px-6 lg:px-8 md:space-y-6 space-y-3">
            <div class="">
                <!-- Judul -->
                <h3 class="text-xl font-semibold text-gray-700 my-4">Yang Akan Didapatkan</h3>
                                
                <!-- Daftar Button -->
                <div class="flex flex-col sm:flex-row sm:space-x-4 space-y-4 sm:space-y-0">
                    <button class="bg-[#08072a] hover:bg-gray-500 text-white font-semibold py-2 px-3 rounded-lg text-sm shadow-lg shadow-gray-200 hover:shadow-none flex items-center space-x-2" data-aos="zoom-in-right">
                        <img class="w-6 h-6" style="filter: invert(1);" src="https://img.icons8.com/fluency-systems-regular/50/certificate--v1.png" alt="certificate--v1"/>
                        <span>Sertifikat</span>
                    </button>
                    <button class="bg-[#08072a] hover:bg-gray-500 text-white font-semibold py-2 px-3 rounded-lg text-sm shadow-lg shadow-gray-200 hover:shadow-none flex items-center space-x-2" data-aos="zoom-in-right">
                        <img class="w-6 h-6" style="filter: invert(1);" src="https://img.icons8.com/ios-glyphs/30/last-24-hours.png" alt="last-24-hours"/>
                        <span>Akses Materi 24 Jam</span>
                    </button>
                    
                    <button class="bg-[#08072a] hover:bg-gray-500 text-white font-semibold py-2 px-3 rounded-lg text-sm shadow-lg shadow-gray-200 hover:shadow-none flex items-center space-x-2" data-aos="zoom-in-right">
                        <img class="w-6 h-6" style="filter: invert(1);" src="https://img.icons8.com/sf-black/64/cinema-.png" alt="cinema-"/>
                        <span>Video Pembelajaran</span>
                    </button>
                    <button class="bg-[#08072a] hover:bg-gray-500 text-white font-semibold py-2 px-3 rounded-lg text-sm shadow-lg shadow-gray-200 hover:shadow-none flex items-center space-x-2" data-aos="zoom-in-right">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.057 1.123-.08M15.75 18H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08M15.75 18.75v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5A3.375 3.375 0 0 0 6.375 7.5H5.25m11.9-3.664A2.251 2.251 0 0 0 15 2.25h-1.5a2.251 2.251 0 0 0-2.15 1.586m5.8 0c.065.21.1.433.1.664v.75h-6V4.5c0-.231.035-.454.1-.664M6.75 7.5H4.875c-.621 0-1.125.504-1.125 1.125v12c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V16.5a9 9 0 0 0-9-9Z" />
                        </svg>
                        <span>Latihan Soal</span>
                    </button>
                </div>                     
            </div> 

            <h3 class="text-xl font-semibold text-gray-700">Rating Kursus</h3>

            <?php
                $filteredRatings = $ratings->filter(fn($rating) => $rating->display == 1);
            ?>

            <?php if($filteredRatings->isEmpty()): ?>
                <p class="text-gray-500 mt-2">Belum ada rating</p>
            <?php else: ?>
                <div 
                    x-data="{
                        scrollEl: null,
                        scrollAmount: 320,
                        autoScrollInterval: null,
                        init() {
                            this.scrollEl = this.$refs.slider;
                            this.startAutoScroll();
                        },
                        scrollLeft() {
                            this.scrollEl.scrollBy({ left: -this.scrollAmount, behavior: 'smooth' });
                        },
                        scrollRight() {
                            this.scrollEl.scrollBy({ left: this.scrollAmount, behavior: 'smooth' });
                        },
                        startAutoScroll() {
                            this.autoScrollInterval = setInterval(() => this.scrollRight(), 3000);
                        },
                        stopAutoScroll() {
                            clearInterval(this.autoScrollInterval);
                        }
                    }"
                    x-init="init()"
                    class="relative mt-4"
                >
                    <!-- Tombol Kiri -->
                    <button @click="scrollLeft" class="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-gray-50 text-gray-700 p-2 rounded-full shadow hover:bg-gray-100">
                        &#8592;
                    </button>

                    <!-- Slider -->
                    <div 
                        x-ref="slider"
                        @mouseover="stopAutoScroll()"
                        @mouseout="startAutoScroll()"
                        class="flex overflow-x-auto no-scrollbar scroll-smooth space-x-4 px-8"
                    >
                        <?php $__currentLoopData = $filteredRatings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="min-w-[300px] max-w-[300px] h-[150px] flex-shrink-0 border border-gray-200 rounded-xl p-4 hover:shadow-lg transition-shadow duration-300 ease-in-out" data-aos="zoom-in-up">
                            <!-- Nama, Foto & Tanggal -->
                            <div class="flex items-center space-x-2">
                                <img src="<?php echo e(asset('storage/default-profile.jpg')); ?>" alt="Foto Profil" class="w-6 h-6 rounded-full object-cover">
                                <div>
                                    <h4 class="text-sm font-semibold text-gray-800"><?php echo e($rating->user->name); ?></h4>
                                    <span class="text-xs text-gray-500"><?php echo e(\Carbon\Carbon::parse($rating->created_at)->format('d F Y')); ?></span>
                                </div>
                            </div>

                            <!-- Rating Bintang -->
                            <div class="flex items-center space-x-1">
                                <?php for($i = 0; $i < 5; $i++): ?>
                                    <span class="<?php echo e($i < $rating->stars ? 'text-yellow-500' : 'text-gray-300'); ?>">&starf;</span>
                                <?php endfor; ?>
                            </div>

                            <!-- Komentar -->
                            <p class="text-gray-700 text-sm overflow-hidden text-ellipsis line-clamp-3">
                                <?php echo e($rating->comment); ?>

                            </p>
                            </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <!-- Tombol Kanan -->
                            <button @click="scrollRight" class="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-gray-50 text-gray-700 p-2 rounded-full shadow hover:bg-gray-100">
                                &#8594;
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
    </section>

<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Menambahkan Footer -->

<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    // Initialize AOS animation
    AOS.init({
        duration: 1000, 
        once: true,    
    });
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\kursus-sibermuda\resources\views/kursus-detail.blade.php ENDPATH**/ ?>